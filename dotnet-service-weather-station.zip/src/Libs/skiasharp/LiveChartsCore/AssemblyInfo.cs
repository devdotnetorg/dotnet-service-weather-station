﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LiveChartsCore.SkiaSharpView")]
[assembly: InternalsVisibleTo("LiveChartsCore.SkiaSharpView.Avalonia")]
[assembly: InternalsVisibleTo("LiveChartsCore.SkiaSharpView.WinForms")]
[assembly: InternalsVisibleTo("LiveChartsCore.SkiaSharpView.WPF")]
[assembly: InternalsVisibleTo("LiveChartsCore.SkiaSharpView.XamarinForms")]
[assembly: InternalsVisibleTo("LiveChartsBackersPackage")]
