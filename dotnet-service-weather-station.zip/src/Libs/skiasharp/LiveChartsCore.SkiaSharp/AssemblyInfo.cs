﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LiveChartsBackersPackage")]
